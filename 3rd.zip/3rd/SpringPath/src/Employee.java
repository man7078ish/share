import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {
private int employeeId;
private String name;
private double salary;
private LocalDate doj;
private ArrayList<String> skills;
public ArrayList<String> getSkills() {
	return skills;
}
public void setSkills(ArrayList<String> skills) {
	this.skills = skills;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public LocalDate getDoj() {
	return doj;
}
public void setDoj(LocalDate doj) {
	this.doj = doj;
}
public Employee(int employeeId, String name, double salary, LocalDate doj) {
	super();
	this.employeeId = employeeId;
	this.name = name;
	this.salary = salary;
	this.doj = doj;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + ", doj=" + doj + ", skills="
			+ skills + "]";
}

}
