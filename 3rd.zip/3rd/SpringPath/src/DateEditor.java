import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateEditor extends PropertyEditorSupport{
	@Override
	public void setAsText(String arg0) throws IllegalArgumentException {
		
		//arg0 will contain the date in string format
		//below logic will convert the string to local date
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate dt=LocalDate.parse(arg0, formatter);
		setValue(dt);
	}
}
