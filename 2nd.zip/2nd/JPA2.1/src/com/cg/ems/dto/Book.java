package com.cg.ems.dto;

//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Table;

//@Entity
//@Table(name="book_table")
public class Book {
//@Column(name="ISBN",length=10)
 private int isbn;
//@Column(name="Title",length=25)
 private String title;
//@Column(name="Price",length=10)
 private float price;
public Book() 
{
	super();
	
}
public Book(int isbn, String title, float price) {
	super();
	this.isbn = isbn;
	this.title = title;
	this.price = price;
}
public int getIsbn() {
	return isbn;
}
public void setIsbn(int isbn) {
	this.isbn = isbn;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}

@Override
public String toString() {
	return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
}

}
