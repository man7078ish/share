package com.cg.ems.dto;

public class Author {
private int Id;
private String Name;

public int getId() {
	return Id;
}
public void setId(int id) {
	Id = id;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}

public Author(int id, String name) {
	super();
	Id = id;
	Name = name;
}
public Author() {
	super();
	
}
@Override
public String toString() {
	return "Author [Id=" + Id + ", Name=" + Name + "]";
}

}
