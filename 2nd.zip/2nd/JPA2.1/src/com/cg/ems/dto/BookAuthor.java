package com.cg.ems.dto;

public class BookAuthor {
private Book book;
private Author author;

}
