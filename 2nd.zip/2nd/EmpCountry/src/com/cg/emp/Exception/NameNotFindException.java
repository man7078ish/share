package com.cg.emp.Exception;

public class NameNotFindException extends Exception {

}
