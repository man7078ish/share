package com.cg.emp.Exception;

public class IdNotgivenException extends Exception{

}
