package com.cg.emp.Exception;

public class NameNotGivenException extends Exception {

}
