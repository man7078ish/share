package com.cg.emp.Exception;

public class DuplicateIdException extends Exception{

}
