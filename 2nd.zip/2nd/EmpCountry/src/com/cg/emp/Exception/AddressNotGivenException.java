package com.cg.emp.Exception;


	public class AddressNotGivenException extends Exception {

	}

