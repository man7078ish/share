package com.cg.emp.bean;

public class Address {
 
   private String addressline;
  private Country country;
  public Address(String addressline, Country country) {
		super();
		this.addressline = addressline;
		this.country = country;
	}
public String getaddressline() {
	return addressline;
}
public void setName(String addressline) {
	this.addressline = addressline;
}
public Country getCountry() {
	return country;
}
public void setCountry(Country country) {
	this.country = country;
}
@Override
public String toString() {
	return "Address [Addressline=" + addressline + ", country=" + country + "]";
}
  
}
