package com.cg.emp.bean;

public class City {
 private  String Cityname;

public City(String Cityname) {
	super();
	this.Cityname = Cityname;
}

public String getCityname() {
	return Cityname;
}

public void setName(String Cityname) {
	this.Cityname = Cityname;
}

@Override
public String toString() {
	return "City [Cityname=" + Cityname + "]";
}
 
}
