package com.cg.emp.View;
import com.cg.emp.Exception.AddressNotGivenException;
import com.cg.emp.Exception.DuplicateIdException;
import com.cg.emp.Exception.IdNotgivenException;
import com.cg.emp.Exception.NameNotFindException;
import com.cg.emp.Exception.NameNotGivenException;
import com.cg.emp.bean.Address;
import com.cg.emp.bean.City;
import com.cg.emp.bean.Country;
import com.cg.emp.repository.EmployeeRepo;
import com.cg.emp.repository.EmployeeRepoImpl;
import com.cg.emp.service.EmployeeService;

public class Main {
	
	public static void main(String[] args) throws NameNotGivenException, IdNotgivenException, AddressNotGivenException, DuplicateIdException, NameNotFindException {
		
		EmployeeRepo empRepo = new EmployeeRepoImpl();
		EmployeeService empService  = new EmployeeService(empRepo);
		 
		City city = new City("pune");
		Country country = new Country("india", city);
		Address add = new Address("Nigdi", country);
		
		City city1 = new City("delhi");
		Country country1 = new Country("india", city1);
		Address add1 = new Address("aashirwaad", country1);
		try {
		empService.createEmployee("123", "Yashi", add);
		empService.createEmployee("456", "shiVANI", add1);
		}
		catch(Exception e) {
			
		}
		System.out.println(empService.searchByName("shivani"));
	}

}
