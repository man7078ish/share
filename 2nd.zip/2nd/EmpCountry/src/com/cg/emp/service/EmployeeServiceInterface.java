package com.cg.emp.service;



import java.util.List;

import com.cg.emp.Exception.AddressNotGivenException;
import com.cg.emp.Exception.DuplicateIdException;
import com.cg.emp.Exception.IdNotgivenException;
import com.cg.emp.Exception.NameNotFindException;
import com.cg.emp.Exception.NameNotGivenException;
import com.cg.emp.bean.Address;
import com.cg.emp.bean.Employee;

public interface EmployeeServiceInterface {

	Employee createEmployee(String id, String name, Address address) throws NameNotGivenException, IdNotgivenException, AddressNotGivenException, DuplicateIdException;

	List<Employee> searchByName(String name) throws NameNotGivenException, NameNotFindException;

}