package com.cg.emp.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.emp.Exception.AddressNotGivenException;
import com.cg.emp.Exception.DuplicateIdException;
import com.cg.emp.Exception.IdNotgivenException;
import com.cg.emp.Exception.NameNotFindException;
import com.cg.emp.Exception.NameNotGivenException;
import com.cg.emp.bean.Address;
import com.cg.emp.bean.City;
import com.cg.emp.bean.Country;
import com.cg.emp.bean.Employee;
import com.cg.emp.repository.EmployeeRepo;

public class EmployeeService implements EmployeeServiceInterface {
	
	EmployeeRepo employeeRepo;
	
	public EmployeeService(EmployeeRepo employeeRepo)
	{
		this.employeeRepo = employeeRepo;
	}
	
	
	@Override
	public Employee createEmployee(String id, String name, Address address) throws NameNotGivenException, IdNotgivenException, AddressNotGivenException, DuplicateIdException
	{
		if(name == "")
			throw new NameNotGivenException();
		if(id == "")
			throw new IdNotgivenException();
		if(address.getaddressline()==""||address.getCountry().getCity() == null);
			throw new AddressNotGivenException();
		/*if()
			throw new AddressNotGivenException();*/
		if(searchId(id))
			throw new DuplicateIdException();
		 Employee e = new Employee();
		 e.setId(id);
		 e.setName(name);
		 e.setAddress(address);
		 return employeeRepo.save(e);
	}
	
	
	@Override
	public List<Employee> searchByName(String name) throws NameNotGivenException, NameNotFindException 
	{
		if(name == "")
			throw new NameNotGivenException();
		
		if(employeeRepo.findByName(name).isEmpty()) {
			System.out.println("name is not find");
			throw new NameNotFindException();
		}
			
		return	employeeRepo.findByName(name);
	}
	
	public boolean searchId(String id)
	{
		return employeeRepo.search(id);
		
	}
}