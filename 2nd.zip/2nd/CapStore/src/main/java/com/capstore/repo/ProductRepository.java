package com.capstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.beans.Product;

import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {
    Optional<Product> findById(Long id);

	Product findOne(Long id);
}
