package com.cg.poj.bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="book")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
 private int ISBN;
 private String title;
 private float price;
 @ManyToMany(mappedBy="bookSet")
 List<Author> authorSet=new ArrayList<>();
public int getISBN() {
	return ISBN;
}
public void setISBN(int iSBN) {
	ISBN = iSBN;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public List<Author> getAuthorSet() {
	return authorSet;
}
public void setAuthorSet(List<Author> authorSet) {
	this.authorSet = authorSet;
}
public Book(int iSBN, String title, float price, List<Author> authorSet) {
	super();
	ISBN = iSBN;
	this.title = title;
	this.price = price;
	this.authorSet = authorSet;
}
public Book() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price + ", authorSet=" + authorSet + "]";
}

}
