package com.cg.poj.bean;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.Generated;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;



@Entity
@Table(name="author")
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="record",
	joinColumns= {@JoinColumn(name="id")},
	inverseJoinColumns= {@JoinColumn(name="ISBN")	}	)
	List<Book> bookSet=new ArrayList<>();
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Book> getBookSet() {
		return bookSet;
	}
	public void setBookSet(List<Book> bookSet) {
		this.bookSet = bookSet;
	}
	public Author(int id, String name, List<Book> bookSet) {
		super();
		this.id = id;
		this.name = name;
		this.bookSet = bookSet;
	}
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", bookSet=" + bookSet + "]";
	}
	
}
