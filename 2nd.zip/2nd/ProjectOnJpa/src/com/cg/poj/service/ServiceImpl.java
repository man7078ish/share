package com.cg.poj.service;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.poj.bean.Author;
import com.cg.poj.util.JPAUtil;

public class ServiceImpl implements Service{
	EntityManager em=null;
    EntityTransaction entityTran=null;
    public ServiceImpl() {
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
		
	}
	@Override
	public Author addAuthor(Author a) {
		entityTran.begin();
		em.persist(a);
		entityTran.commit();
		return a;
	}

	@Override
	public ArrayList<Author> showAuthor() {
		// TODO Auto-generated method stub
		//JPQL
				String selAllQry="SELECT id,name FROM author";
				
				//SELECT  emp FROM Employee emp WHERE emp.empId=555;for find
				TypedQuery<Author> tq=em.createQuery(selAllQry,Author.class);
				ArrayList<Author> empList=(ArrayList)tq.getResultList();
		return empList;
	}

}
