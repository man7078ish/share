package com.cg.poj.service;

import java.util.ArrayList;

import com.cg.poj.bean.Author;

public interface Service {
	public Author addAuthor(Author a);
	public ArrayList<Author> showAuthor();
}
