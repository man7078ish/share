package com.cg.poj.ui;

import java.util.ArrayList;
import java.util.List;

import com.cg.poj.bean.Author;
import com.cg.poj.bean.Book;
import com.cg.poj.service.Service;
import com.cg.poj.service.ServiceImpl;

public class Main {
	public static void main(String[] args) {
		Service service=new ServiceImpl();
		List<Book> list=new ArrayList<>();
		Author a=new Author();
		a.setName("Manish");
		Book book=new Book();
		book.setTitle("Kuch nahi");
		book.setPrice(500);
		list.add(book);
		a.setBookSet(list);
		service.addAuthor(a);
		service.showAuthor();
	}
}
