

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;


import com.cg.ems.dto.Product;
import com.cg.ems.dto.Supplier;
import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Product p1=new Product();
		p1.setProductCode(100);
		p1.setProdName("TV");
		p1.setProductprice(35000);
	
		Product p2=new Product();
		p2.setProductCode(200);
		p2.setProdName("Refrigerator");
		p2.setProductprice(36000);
		
		Product p3=new Product();
		p3.setProductCode(300);
		p3.setProdName("CD");
		p3.setProductprice(1300);
		
		Product p4=new Product();
		p4.setProductCode(400);
		p4.setProdName("Laptop");
		p4.setProductprice(23000);
		
		Set<Product> elecProSet = new HashSet<Product>();
		elecProSet.add(p1);
		elecProSet.add(p2);
		elecProSet.add(p3);
		//elecProSet.add(p4);
		
		Supplier sony=new Supplier();
		sony.setSupplierId(111);
		sony.setSupplyDate(new Date());
		sony.setProductSet(elecProSet);
		
		
		Supplier LG=new Supplier();
		LG.setSupplierId(222);
		LG.setSupplyDate(new Date(2018,12,04));
		Set<Supplier> SuppSet = new HashSet<Supplier>();
		SuppSet.add(sony);
		SuppSet.add(LG);

		p1.setSupSet(SuppSet);
		
	  
	et.begin();
	em.persist(sony);
	/*em.persist(LG);
	em.persist(p3);
	em.persist(p4);*/
	et.commit(); 
	System.out.println("Product inserted");
	}
	

}
