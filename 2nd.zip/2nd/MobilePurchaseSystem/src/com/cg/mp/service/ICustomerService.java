package com.cg.mp.service;

public interface ICustomerService {
	void addCustomerName(String custname);

	void addCustomerMailid(String custmailid);

	void addCustomerPurchaseid();

	void addCustomerPurchasedate();

	void addCustomerPhoneno(String custphoneno);

	void addCustomerMobileid(String mobilename);
}
