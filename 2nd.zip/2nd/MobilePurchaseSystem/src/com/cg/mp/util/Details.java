package com.cg.mp.util;

public interface Details {
void addMobile();
void deleteByid();
int availableMobiles();


}
