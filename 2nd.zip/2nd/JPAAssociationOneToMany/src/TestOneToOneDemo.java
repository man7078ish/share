import java.util.HashSet;



import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Department;
import com.cg.ems.dto.Employee;

import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Department d1=new Department();
		d1.setDeptCode(10);
		d1.setDeptname("Admin");
		
		Department d2=new Department();
		d2.setDeptCode(20);
		d2.setDeptname("Sales");
		
		Employee e1=new Employee();
		e1.setEmpName("VaishaliS");
		e1.setEmpId(2000);
		e1.setEmpSal(2000.0F);
		e1.setEmpDept(d1);
		
		Employee e2=new Employee();
		e2.setEmpName("Manish");
		e2.setEmpId(4000);
		e2.setEmpSal(5000.0F);
		e2.setEmpDept(d1);

		Employee e3=new Employee();
		e3.setEmpName("yashi");
		e3.setEmpId(3000);
		e3.setEmpSal(3000.0F);
		e3.setEmpDept(d2);

		Employee e4=new Employee();
		e4.setEmpName("Shivani");
		e4.setEmpId(6000);
		e4.setEmpSal(7000.0F);
		e4.setEmpDept(d2);
		
	HashSet<Employee> adminEmpSet=new HashSet<Employee>();
	HashSet<Employee> saleEmpSet=new HashSet<Employee>();
	
	adminEmpSet.add(e1);
	adminEmpSet.add(e2);
	
	saleEmpSet.add(e3);
	saleEmpSet.add(e4);
	
	d1.setEmpSet(adminEmpSet);
	d2.setEmpSet(saleEmpSet);
	
	et.begin();
	em.persist(d1);
	em.persist(d2);
	et.commit();
	
	System.out.println("employee inserted");
	}
	

}
