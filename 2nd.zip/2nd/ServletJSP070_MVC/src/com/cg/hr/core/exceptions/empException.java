package com.cg.hr.core.exceptions;

public class empException extends Exception {

	public empException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public empException(String arg0) {
		super(arg0);
		
	}
	
}
