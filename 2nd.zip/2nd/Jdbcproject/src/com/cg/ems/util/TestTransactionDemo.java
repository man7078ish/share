package com.cg.ems.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TestTransactionDemo {
   public static void main(String[] args) {
	   Connection con=null;
	   try {
		con=DButil.getCon();
		   con.setAutoCommit(false);
		   String update1="Update emp1 set emp_name='Vaishali' Where emp_id=111 ";
		   String update2= "Update emp1 set emp_sal=306" + " where emp_id=222 ";
		   Statement st=con.createStatement();
		   st.addBatch(update1);
		   st.addBatch(update2);
		   int arr[]=st.executeBatch();
		   con.commit();
		   System.out.println("Updation successful");
		   
	   }
	   catch(SQLException | IOException e) {
		 try {
			 con.rollback();
		 }
		 catch(SQLException e1) {
			 e1.printStackTrace();
			 
		 }
		 e.printStackTrace();
		 
	   }
   }
}
