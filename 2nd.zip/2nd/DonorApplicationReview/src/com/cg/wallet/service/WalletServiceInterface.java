package com.cg.wallet.service;
import java.math.BigDecimal;

import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.*;

public interface WalletServiceInterface {


	Customer showBalance(String mobileNo) throws MobilenumberIsNotFoundException;

	Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InsufficientBalanceException, MobilenumberIsNotFoundException;

	Customer depositAmount(String mobileNo, BigDecimal amount) throws MobilenumberIsNotFoundException;

	Customer withDrawAmount(String mobileNo, BigDecimal amount) throws  MobilenumberIsNotFoundException, InsufficientBalanceException;

	Customer createAccount(String name, String mobileNo, Wallet wallet) throws DuplicateMobileNumberException;

}

