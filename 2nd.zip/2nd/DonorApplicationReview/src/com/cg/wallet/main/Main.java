package com.cg.wallet.main;
import java.math.BigDecimal;
import com.cg.wallet.bean.Customer;
import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.DuplicateMobileNumberException;
import com.cg.wallet.exception.InsufficientBalanceException;

import com.cg.wallet.exception.MobilenumberIsNotFoundException;
import comn.cg.wallet.repository.WalletRepo;
import comn.cg.wallet.repository.WalletRepoImpl;
import com.cg.wallet.service.WalletServiceInterface;
import com.cg.wallet.service.WalletServiceImpl;

public class Main{

	public static void main(String[] args) throws InsufficientBalanceException, DuplicateMobileNumberException, MobilenumberIsNotFoundException {
		
		WalletRepo walletRepo = new WalletRepoImpl();
		WalletServiceInterface walletService = new WalletServiceImpl(walletRepo);
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		System.out.println(walletService.createAccount("vikash", "8171575996", wallet1));
		
		BigDecimal amount2 = new BigDecimal(500);
		Wallet wallet2 = new Wallet(amount2);
		
		System.out.println(walletService.createAccount("shivam,", "9761490311", wallet2));
		
		BigDecimal transferAmount = new BigDecimal(500);
		System.out.println(walletService.fundTransfer("8171575996", "9761490311", transferAmount));


	}

}