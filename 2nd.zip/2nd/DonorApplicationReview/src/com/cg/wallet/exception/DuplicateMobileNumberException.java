package com.cg.wallet.exception;

public class DuplicateMobileNumberException extends Exception {

}
