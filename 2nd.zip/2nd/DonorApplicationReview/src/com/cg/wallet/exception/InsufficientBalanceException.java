package com.cg.wallet.exception;

public class InsufficientBalanceException extends Exception {

}
