package com.cg.wallet.exception;

public class MobilenumberIsNotFoundException extends Exception{

}
