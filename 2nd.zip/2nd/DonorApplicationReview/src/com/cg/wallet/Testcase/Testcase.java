package com.cg.wallet.Testcase;


import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

import com.cg.wallet.bean.Wallet;
import com.cg.wallet.exception.DuplicateMobileNumberException;
import com.cg.wallet.exception.InsufficientBalanceException;
import com.cg.wallet.exception.MobilenumberIsNotFoundException;
import comn.cg.wallet.repository.WalletRepo;
import comn.cg.wallet.repository.WalletRepoImpl;



import com.cg.wallet.service.WalletServiceImpl;
import com.cg.wallet.service.WalletServiceInterface;

public class Testcase{

	
	WalletRepo walletRepo = new WalletRepoImpl();
	WalletServiceInterface walletservice = new WalletServiceImpl(walletRepo);
	
	
	@Before
	public void setUp() throws Exception{
		walletservice = new WalletServiceImpl(walletRepo);
	}
	@Test(expected = com.cg.wallet.exception.InsufficientBalanceException.class)
	public void WhenTheBalanceIsNotEnoughToWithDrawThenThrowAnError() throws InsufficientBalanceException, DuplicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletRepo.save(walletservice.createAccount("vikash", "8171575996", wallet1));
		
		BigDecimal withdrawAmount = new BigDecimal(2000);
		walletservice.withDrawAmount("8171575996", withdrawAmount );
	}
	
	@Test(expected = com.cg.wallet.exception.InsufficientBalanceException.class)
	public void WhenTheBalanceIsNotEnoughToTransferThenThrowAnError() throws InsufficientBalanceException, DuplicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
		BigDecimal amount2 = new BigDecimal(500);
		Wallet wallet2 = new Wallet(amount2);
		
		walletRepo.save(walletservice.createAccount("balveer", "8755560521", wallet2));
		
		BigDecimal fundTransfer = new BigDecimal(2000);
		walletservice.fundTransfer("8171575996", "8755560521", fundTransfer);
		
	}
	
	@Test(expected = com.cg.wallet.exception.DuplicateMobileNumberException.class)
	public void WhenTheMobileNumberIsDuplicateThenThrowAnError() throws InsufficientBalanceException, DupicateMobileNumberException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletRepo.save(walletservice.createAccount("vikash", "8171575996", wallet1));
		
		BigDecimal amount2 = new BigDecimal(500);
		Wallet wallet2 = new Wallet(amount2);
		
		walletRepo.save(walletservice.createAccount("balveer", "8171575996", wallet2));
		
	}
	
	@Test(expected = com.cg.wallet.exception.MobilenumberIsNotFoundException.class)
	public void WhenTheMobileNumberIsNotFoundToShowBalanceThenThrowAnError() throws InsufficientBalanceException, DupicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletRepo.save(walletservice.createAccount("vikash", "8171575996", wallet1));
		
		walletservice.showBalance("8755560521");
	}
	
	
	@Test(expected = com.cg.wallet.exception.MobilenumberIsNotFoundException.class)
	public void WhenTheMobileNumberIsNotFoundToFundTransferThenThrowAnError() throws InsufficientBalanceException, DupicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletRepo.save(walletservice.createAccount("vikash", "8171575996", wallet1));
		
		BigDecimal amount2 = new BigDecimal(500);
		Wallet wallet2 = new Wallet(amount2);
		
		walletRepo.save(walletservice.createAccount("balveer", "8755560521", wallet2));
		
		BigDecimal amount3 = new BigDecimal(500);
		walletservice.fundTransfer("8171575996", "9761490311", amount3);
		
	}
	
	
	@Test(expected = com.cg.wallet.exception.MobilenumberIsNotFoundException.class)
	public void WhenTheMobileNumberIsNotFoundToDepositAmountThenThrowAnError() throws InsufficientBalanceException, DupicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletRepo.save(walletservice.createAccount("vikash", "8171575996", wallet1));
		
		BigDecimal amount = new BigDecimal(500);
		walletservice.depositAmount("8755560521", amount);
	}
	
	
	@Test(expected = com.cg.wallet.exception.MobilenumberIsNotFoundException.class)
	public void WhenTheMobileNumberIsNotFoundToWithDrawAmountThenThrowAnError() throws InsufficientBalanceException, DupicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
		BigDecimal amount = new BigDecimal(500);
		walletservice.depositAmount("8755560521", amount);
	}
	
	@Test
	public void WhenTheAllTheDetailsGivenValidThenAccountCreatedSuccessfully() throws DuplicateMobileNumberException {
	
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
	}
	
	@Test
	public void WhenTheAllTheDetailsGivenValidThenDepositedSuccessfully() throws DuplicateMobileNumberException, MobilenumberIsNotFoundException{
	
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
		BigDecimal amount = new BigDecimal(500);
		walletservice.depositAmount("8171575996", amount);
		
	}
	
	@Test
	public void WhenTheAllTheDetailsGivenValidThenTheAmountWithDrawSuccessfully() throws DuplicateMobileNumberException, MobilenumberIsNotFoundException, InsufficientBalanceException 
	{
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
		BigDecimal amount = new BigDecimal(500);
		walletservice.withDrawAmount("8171575996", amount);
		
	}
	
	
	@Test
	public void WhenAllTheDetailsGivenValidThenTheFundTransferredSuccessfully() throws InsufficientBalanceException, DuplicateMobileNumberException, MobilenumberIsNotFoundException {
		
		BigDecimal amount1 = new BigDecimal(1000);
		Wallet wallet1 = new Wallet(amount1);
		
		walletservice.createAccount("vikash", "8171575996", wallet1);
		
		BigDecimal amount2 = new BigDecimal(500);
		Wallet wallet2 = new Wallet(amount2);
		
		walletservice.createAccount("balveer", "8755560521", wallet2);
		
		BigDecimal amount3 = new BigDecimal(500);
		walletservice.fundTransfer("8171575996", "8755560521", amount3);
		
	}
	
	
	

}