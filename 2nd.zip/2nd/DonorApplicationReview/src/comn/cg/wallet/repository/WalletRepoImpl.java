package comn.cg.wallet.repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import com.cg.wallet.bean.Customer;

public class WalletRepoImpl implements WalletRepo{
  
Map<String, Customer> customers  = new HashMap<String, Customer>();
	
	@Override
	public boolean save(Customer customer) {
		
		customers.put(customer.getMobileNo(), customer);
		return true;
	}
	
	
	@Override
	public Customer findOne(String mobileNo) {
		
		for (Map.Entry<String, Customer> entry : customers.entrySet())  {
				
			if(entry.getValue().getMobileNo().equals(mobileNo))
				return entry.getValue();
			  
		}
		return null;
	}
}