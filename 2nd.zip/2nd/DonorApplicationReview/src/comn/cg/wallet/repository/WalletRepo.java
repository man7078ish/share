package comn.cg.wallet.repository;
import java.util.List;
import com.cg.wallet.bean.Customer;

public interface WalletRepo {

  boolean save(Customer Customer);

Customer findOne(String mobileNo);

  
}
