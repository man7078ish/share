package com.cg.takehome.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import com.cg.takehome.dao.IProductDao;
import com.cg.takehome.dao.ProductDao;

class TestDao {

	@Before
	public void runEachTime() {
		System.out.println("Run before each test case");

	}

	@Test
	public void test1Dao() {
		IProductDao a = new ProductDao();
		a.getProductDetails(1001);
	}
}
