package com.cg.takehome.service;

import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductCodeNotExistException;

public interface IProductService {
	Product getProductDetails(int ProductCode) throws ProductCodeNotExistException;
}
