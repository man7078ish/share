package com.cg.takehome.service;

import java.util.regex.Pattern;

import com.cg.takehome.bean.Product;
import com.cg.takehome.dao.IProductDao;
import com.cg.takehome.dao.ProductDao;
import com.cg.takehome.exception.ProductCodeNotExistException;

public class ProductService implements IProductService  {
IProductDao productdao=new ProductDao();
	@Override
	public Product getProductDetails(int ProductCode) throws ProductCodeNotExistException{
	if(codeValidation(ProductCode))
		return productdao.getProductDetails(ProductCode);
		System.err.println("product code should be of 4 digit");
		throw new ProductCodeNotExistException("ABC");
	}
	public boolean codeValidation(int ProductCode) {
		String s=Integer.toString(ProductCode);
		if(Pattern.matches("[0-9]{4}", s))
			return true;
		else
			return false;
	}
	public boolean quantityValidation(int ProductQuantity) {
		if(ProductQuantity>0)
			return true;
		else
			return false;
	}

}
