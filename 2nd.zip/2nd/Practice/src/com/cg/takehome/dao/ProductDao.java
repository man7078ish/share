package com.cg.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.takehome.bean.Product;
import com.cg.takehome.util.CollectionUtil;

public class ProductDao implements IProductDao {
	CollectionUtil collectionutil = new CollectionUtil();
	private static Map<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public Product getProductDetails(int ProductCode) {
		products = collectionutil.getList();
		for (Map.Entry<Integer, Product> map : products.entrySet()) {
			if (map.getValue().getProductId() == ProductCode)
				return map.getValue();

		}
		return null;
	}

}
