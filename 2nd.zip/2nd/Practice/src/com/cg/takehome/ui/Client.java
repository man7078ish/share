package com.cg.takehome.ui;

import java.util.Scanner;

import com.cg.takehome.bean.Product;
import com.cg.takehome.exception.ProductCodeNotExistException;
import com.cg.takehome.service.IProductService;
import com.cg.takehome.service.ProductService;

public class Client {

	static IProductService productservice = new ProductService();
	static Product product = new Product();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		show();
	}

	public static void show() {

		while (true) {
			System.out.println("Enter 1 for generate value");
			System.out.println("Enter 2 for Exit");
			System.out.println("Enter the choice");
			int scan = scanner.nextInt();
			switch (scan) {
			case 1:
				ProductDetails();
				break;
			case 2:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
			}
		}

	}

	public static void ProductDetails() {
		int f = 0;
		System.out.println("Enter the product details");
		System.out.println("Enter the product code");
		int productCode = scanner.nextInt();
		System.out.println("Enter the quantity");
		int quantity = scanner.nextInt();
		if (new ProductService().quantityValidation(quantity)) {
			try {
				product = productservice.getProductDetails(productCode);
			} catch (ProductCodeNotExistException e) {
				// TODO Auto-generated catch block
				
			}
			f = 1;
		}
		if (f == 1) {
			System.out.println("Line total is:" + quantity * product.getProductprice());
			System.out.println("Product name is:" + product.getProductName());
			System.out.println("product price is:" + product.getProductprice());
			System.out.println("product code is" + product.getProductId());
		}

	}
}
