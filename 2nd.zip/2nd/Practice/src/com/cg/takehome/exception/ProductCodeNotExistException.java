package com.cg.takehome.exception;

public class ProductCodeNotExistException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductCodeNotExistException(String message) {
		super(message);
	}

}
