package check;

public class TestCollection {
 public static void main(String[] args)
 {
	            
 }
}
