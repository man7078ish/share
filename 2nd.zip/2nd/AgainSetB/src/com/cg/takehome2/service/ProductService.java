package com.cg.takehome2.service;

import java.util.regex.Pattern;

import com.cg.takehome2.bean.Product;
import com.cg.takehome2.dao.IProductdao;
import com.cg.takehome2.dao.ProductDao;

public class ProductService implements IProductService {
	IProductdao productdao =null;
	
	public ProductService() {
		super();
		productdao=new ProductDao();
	}

	/* (non-Javadoc)
	 * @see com.cg.takehome2.service.IProductService#getProductDetails(int)
	 */
	@Override
	public Product getProductDetails(int productcode) {
		
		if (codeValidation(productcode))
			return productdao.getProductDetails(productcode);
		return null;
	}

	/* (non-Javadoc)
	 * @see com.cg.takehome2.service.IProductService#codeValidation(int)
	 */
	@Override
	public boolean codeValidation(int productcode) {
		String s = Integer.toString(productcode);
		if (Pattern.matches("[0-9]{4}",s))
			return true;
		else
			return false;
	}

	/* (non-Javadoc)
	 * @see com.cg.takehome2.service.IProductService#quantityValidation(int)
	 */
	@Override
	public boolean quantityValidation(int quantity) {
		if (quantity > 0)
			return true;
		else
			return false;
	}
}
