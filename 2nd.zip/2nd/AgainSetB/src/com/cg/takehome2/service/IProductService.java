package com.cg.takehome2.service;

import com.cg.takehome2.bean.Product;

public interface IProductService {

	Product getProductDetails(int productcode);

	boolean codeValidation(int productcode);

	boolean quantityValidation(int quantity);

}