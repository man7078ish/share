package com.cg.takehome2.exception;

public class InvalidProductCodeException extends Exception{
public InvalidProductCodeException(String msg) {
	super(msg);
}
}
