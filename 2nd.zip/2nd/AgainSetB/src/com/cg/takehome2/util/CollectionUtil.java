package com.cg.takehome2.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.takehome2.bean.Product;

public class CollectionUtil {
public static Map<Integer,Product> map=new HashMap<Integer,Product>();
static {
	map.put(1002,new Product(1001,"iphone","Electronics",35000));
	map.put(1001, new Product(1002,"samsung","Electronics",45000));
	map.put(1003, new Product(1003,"teddy","Toys",800));
	map.put(1004,new Product(1004,"Mr.Bean","Toys",900));
}
public HashMap<Integer,Product> getItems(){
	return (HashMap<Integer,Product>) map;
}

}
