package com.cg.takehome2.dao;

import com.cg.takehome2.bean.Product;

public interface IProductdao {
	Product getProductDetails(int productcode);
}
