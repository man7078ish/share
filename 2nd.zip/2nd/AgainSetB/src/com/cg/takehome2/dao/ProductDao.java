package com.cg.takehome2.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.takehome2.bean.Product;
import com.cg.takehome2.util.CollectionUtil;

public class ProductDao implements IProductdao {
	CollectionUtil collectionutil = null;

	public ProductDao() {
		super();
		collectionutil = new CollectionUtil();
	}

	public Map<Integer, Product> map2 = new HashMap<Integer, Product>();

	@Override
	public Product getProductDetails(int productcode) {
		map2 = collectionutil.getItems();
		for (Map.Entry<Integer, Product> map : map2.entrySet()) {
			if (map.getValue().getPid() == productcode)
				return map.getValue();

		}
		return null;
	}
}