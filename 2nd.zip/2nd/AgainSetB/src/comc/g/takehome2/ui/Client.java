package comc.g.takehome2.ui;

import java.util.Scanner;

import com.cg.takehome2.bean.Product;
import com.cg.takehome2.service.IProductService;
import com.cg.takehome2.service.ProductService;

public class Client {
	public static IProductService productservice = new ProductService();
	static Product product = new Product();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		show();
	}

	public static void show() {
		while (true) {
			System.out.println("Enter 1 for prodcut details");
			System.out.println("enter 2 to exit ");
			int scan = scanner.nextInt();
			switch (scan) {
			case 1:
				ProductDetails();
				break;

			case 2:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice");
				
			}

		}
	}

	public static void ProductDetails() {
		int f = 0;
		System.out.println("Enter the product details");
		System.out.println("Enter the productcode");
		int productcode = scanner.nextInt();
		System.out.println("Enter the quantity ");
		int quantity = scanner.nextInt();
		if (productservice.quantityValidation(quantity)) {
			product = productservice.getProductDetails(productcode);
			
			f = 1;
		}
		if (f == 1) {
			System.out.println("ProductCode" + product.getPid());
			System.out.println("Productname" + product.getPname());
			System.out.println("ProductPrice" + product.getPprice());
			System.out.println("Line Total" + quantity * product.getPprice());
		}
	}
}