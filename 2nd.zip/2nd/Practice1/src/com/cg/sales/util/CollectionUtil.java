package com.cg.sales.util;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.cg.sales.bean.Sale;

public class CollectionUtil {
	Map<Integer, Sale> map = new HashMap<Integer, Sale>();

	public CollectionUtil(Sale sale) {
		map.put(sale.getSaleId(), sale);
	}

	public CollectionUtil() {
		// TODO Auto-generated constructor stub
	}

	public HashMap<Integer, Sale> getCollection() {
		return (HashMap<Integer, Sale>) map;

	}
}
