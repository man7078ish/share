package com.cg.sales.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.sales.bean.Sale;
import com.cg.sales.util.CollectionUtil;

public class Salesdao implements ISalesdao {
	CollectionUtil c = new CollectionUtil();
	Map<Integer, Sale> map = new HashMap<Integer, Sale>();

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		map = c.getCollection();
		return (HashMap<Integer, Sale>) map;
	}

}
