package com.cg.sales.dao;

import java.util.HashMap;

import com.cg.sales.bean.Sale;

public interface ISalesdao {
public HashMap<Integer,Sale> insertSalesDetails(Sale sale);
}
