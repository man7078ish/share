package com.cg.sales.ui;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the product code");
		int i=sc.nextInt();
		System.out.println("Enter the product name");
		String name=sc.next();
		System.out.println("Enter  ");

	}

}
