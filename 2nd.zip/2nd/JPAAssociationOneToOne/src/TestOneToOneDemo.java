import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ems.dto.Address;
import com.cg.ems.dto.Student;
import com.cg.ems.util.JPAUtil;

public class TestOneToOneDemo {

	public static void main(String[] args) {
		EntityManager em=JPAUtil.getEntityManager();
		EntityTransaction et=em.getTransaction();
		Address vAddress = new Address();
		vAddress.setCity("Pune");
		vAddress.setState("Maharashtra");
		vAddress.setStreet("Sinhagad Road");
		vAddress.setZipcode("411041");
		
		Address rAddress = new Address();
		rAddress.setCity("Gaziabad");
		rAddress.setState("Delhi");
		rAddress.setStreet("GT Road");
		rAddress.setZipcode("200731");
		
		Address pAddress = new Address();
		pAddress.setCity("Hoshiapur");
		pAddress.setState("Punjab");
		pAddress.setStreet("Thakur Road");
		pAddress.setZipcode("411941");
		
		Address qAddress = new Address();
		qAddress.setCity("Agra");
		qAddress.setState("UP");
		qAddress.setStreet("Singha Road");
		qAddress.setZipcode("422341");
		
		Student vinita=new Student();
		vinita.setName("Vinita lalwani");
		vinita.setStuAddress(vAddress);
		
		Student rahul=new Student();
		rahul.setName("Rahul Sharma");
		rahul.setStuAddress(rAddress);
		
		Student yashi=new Student();
		yashi.setName("Yashi Garg");
		yashi.setStuAddress(pAddress);
		
		Student divya=new Student();
		divya.setName("Divya Garg");
		divya.setStuAddress(qAddress);
		
		
		et.begin();
		em.persist(vinita);
		em.persist(rahul);
		em.persist(yashi);
		em.persist(divya);
		
		et.commit();
		System.out.println("Data is inserted in table");
		System.out.println("------------Fetch---------");
	}

}
